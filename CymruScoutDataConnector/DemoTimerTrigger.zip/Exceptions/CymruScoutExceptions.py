"""CymruScoutException module is for generating exception."""


class CymruScoutException(Exception):
    """CymruScoutException class will inherit Exception class."""

    pass


class CymruScoutDataNotFoundException(Exception):
    """CymruScoutDataNotFoundException class will inherit Exception class."""

    pass